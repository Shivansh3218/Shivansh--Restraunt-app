# About the project

Static Food app made with custom HTML and CSS 

---

### Click here for the [demo](https://arcane-spire-07518.herokuapp.com/restaurant/)

---

### Screen shot of the application
<img src='Output.png'>
---

### Technology stack

HTML, CSS

---

### What this code base covers

This code is for the front end layout of a traditional food app.


To be modified further by Shivansh
<br/>
Shivansh Rawat, Front end developer